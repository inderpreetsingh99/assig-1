export default [
{"title":"index", "fname":"index.md"},
{"title":"About", "fname":"about.md","specialImage":"https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Range_Rover_Velar.jpg/320px-Range_Rover_Velar.jpg"},
{"title":"Skills", "fname":"skills.md"},
{"title":"Projects", "fname":"projects.md"},
{"title":"contact", "fname":"contact.md"}];
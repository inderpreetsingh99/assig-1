I can be contacted by following ways
=====
Name: Inderpreet Singh\

<b>Mobile No: +1 (519)778-3105M</b>
______

Personal Email: Inderpreet188@gmail.com\

Student Email: Inderpreetsingh1626@conestogac.on.ca
_______

Address: Unit 503 - 271 Lester St, Waterloo, ON N2L-3W6 
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2895.3143014074626!2d-80.53816668428122!3d43.47491077195886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882bf40778d202af%3A0x3b14752fdfc1c3dc!2s271%20Lester%20St%2C%20Waterloo%2C%20ON%20N2L%203W6!5e0!3m2!1sen!2sca!4v1600902215133!5m2!1sen!2sca" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
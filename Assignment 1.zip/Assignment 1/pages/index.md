My name is Inderpreet singh, I am an international student in Conestoga college, Waterloo.


